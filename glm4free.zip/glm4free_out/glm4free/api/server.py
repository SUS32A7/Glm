"""
GLM4Free API Server — Clean rewrite
- OpenAI-compatible /v1/chat/completions + /v1/models
- -nothink model variants: sends base model + enable_thinking=False
- <think> tags streamed through to client as-is
- Session auto-recovery on 401
- System prompt injected into last user message
"""

import uuid, time, json, asyncio, threading
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Optional, List, Literal

from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse, HTMLResponse
from pydantic import BaseModel, Field

from glm4free.client import ZChat, BASE_URL, AVAILABLE_MODELS, DEFAULT_MODEL, generate_za_signature

# ── Model registry ─────────────────────────────────────────────────────────────
MODEL_MAP: dict = {}
for _m in AVAILABLE_MODELS:
    MODEL_MAP[_m]                = (_m, True)
    MODEL_MAP[f"{_m}-nothink"]   = (_m, False)

ALL_MODELS = list(MODEL_MAP.keys())

def resolve_model(name: str):
    return MODEL_MAP.get(name, (DEFAULT_MODEL, True))

# ── Session ────────────────────────────────────────────────────────────────────
_bot = None
_lock = threading.Lock()

def _init_bot():
    global _bot
    _bot = ZChat()
    return _bot.initialize()

def get_bot():
    global _bot
    if not _bot or not _bot.token:
        with _lock:
            if not _bot or not _bot.token:
                if not _init_bot():
                    raise HTTPException(503, "Z.AI session unavailable")
    return _bot

def recover_session():
    global _bot
    with _lock:
        print("[*] Recovering session...")
        if not _init_bot():
            raise HTTPException(503, "Z.AI session recovery failed")
        print(f"[+] Session recovered | user: {_bot.user_name}")

@asynccontextmanager
async def lifespan(app: FastAPI):
    ok = await asyncio.get_event_loop().run_in_executor(None, _init_bot)
    print(f"[+] Ready | user: {_bot.user_name}" if ok else "[!] Session init failed")
    yield

app = FastAPI(title="GLM4Free API", version="2.0.0", lifespan=lifespan)

# ── Helpers ────────────────────────────────────────────────────────────────────
def inject_system(messages: list) -> list:
    system_parts = [m["content"] for m in messages if m["role"] == "system"]
    others = [m for m in messages if m["role"] != "system"]
    if not system_parts:
        return others
    block = "\n\n".join(system_parts)
    result = list(others)
    for i in range(len(result) - 1, -1, -1):
        if result[i]["role"] == "user":
            result[i] = {"role": "user", "content": f"[System]\n{block}\n\n{result[i]['content']}"}
            return result
    result.insert(0, {"role": "user", "content": f"[System]\n{block}"})
    return result

def stream_response(bot, messages: list, web_search: bool, thinking: bool, model: str):
    RETRIES = 3
    RETRY_DELAY = 1.5
    TIMEOUT = 120
    accumulated = ""
    current_msgs = list(messages)

    def make_request(b, msgs):
        prompt = msgs[-1]["content"] if msgs else ""
        sig, _, suffix = generate_za_signature(prompt, b.token, b.user_id, b.salt_key)
        url = f"{BASE_URL}/api/v2/chat/completions?{suffix}"
        now = datetime.now()
        headers = {
            "Origin": BASE_URL, "Referer": f"{BASE_URL}/",
            "Authorization": f"Bearer {b.token}",
            "X-Signature": sig, "X-FE-Version": b.fe_version,
            "Content-Type": "application/json",
        }
        payload = {
            "model": model,
            "chat_id": str(uuid.uuid4()),
            "messages": msgs,
            "signature_prompt": prompt,
            "stream": True,
            "params": {}, "extra": {},
            "features": {
                "image_generation": False,
                "web_search": web_search,
                "auto_web_search": web_search,
                "preview_mode": False,
                "flags": [],
                "enable_thinking": thinking,
            },
            "variables": {
                "{{USER_NAME}}": b.user_name,
                "{{USER_LOCATION}}": "Unknown",
                "{{CURRENT_DATETIME}}": now.strftime("%Y-%m-%d %H:%M:%S"),
                "{{CURRENT_DATE}}": now.strftime("%Y-%m-%d"),
                "{{CURRENT_TIME}}": now.strftime("%H:%M:%S"),
                "{{CURRENT_WEEKDAY}}": now.strftime("%A"),
                "{{CURRENT_TIMEZONE}}": "Europe/Paris",
                "{{USER_LANGUAGE}}": "en-US",
            },
            "background_tasks": {"title_generation": True, "tags_generation": True},
        }
        try:
            with b.session.post(url, headers=headers, json=payload, stream=True, timeout=TIMEOUT) as r:
                if r.status_code == 401:
                    return "AUTH_EXPIRED"
                if r.status_code != 200:
                    print(f"[!] Z.AI error {r.status_code}: {r.text[:200]}")
                    return f"ERROR:{r.status_code}"
                for line in r.iter_lines():
                    if not line:
                        continue
                    decoded = line.decode("utf-8")
                    if not decoded.startswith("data: "):
                        continue
                    data_str = decoded[6:]
                    if data_str == "[DONE]":
                        return "DONE"
                    try:
                        d = json.loads(data_str)
                        chunk = ""
                        if "data" in d:
                            # Z.AI native SSE format
                            reasoning = d["data"].get("delta_reasoning_content") or ""
                            content   = d["data"].get("delta_content") or ""
                            if reasoning:
                                chunk += f"<think>{reasoning}</think>"
                            chunk += content
                        elif "choices" in d:
                            # OpenAI-compatible format
                            delta     = d["choices"][0].get("delta", {})
                            reasoning = delta.get("reasoning_content") or ""
                            content   = delta.get("content") or ""
                            if reasoning:
                                chunk += f"<think>{reasoning}</think>"
                            chunk += content
                        if chunk:
                            yield chunk
                    except Exception:
                        pass
        except Exception as e:
            print(f"[!] Stream error: {e}")
            return "DROPPED"
        return "DROPPED"

    for attempt in range(RETRIES + 1):
        if attempt > 0:
            print(f"[*] Retry {attempt}/{RETRIES}")
            time.sleep(RETRY_DELAY)
            if accumulated.strip():
                current_msgs = list(messages) + [
                    {"role": "assistant", "content": accumulated},
                    {"role": "user", "content": "Continue your response from where you left off."},
                ]
        gen = make_request(bot, current_msgs)
        status = "DROPPED"
        try:
            while True:
                chunk = next(gen)
                accumulated += chunk
                yield chunk
        except StopIteration as e:
            status = e.value or "DROPPED"
        if status == "DONE":
            return
        if status == "AUTH_EXPIRED":
            recover_session()
            bot = _bot
            continue
        if status and status.startswith("ERROR:"):
            return
        if attempt == RETRIES:
            return

# ── Schemas ────────────────────────────────────────────────────────────────────
class Message(BaseModel):
    role:    Literal["system", "user", "assistant"]
    content: str

class ChatRequest(BaseModel):
    model:      str            = Field("glm-5")
    messages:   List[Message]
    stream:     bool           = Field(False)
    web_search: bool           = Field(False)
    thinking:   Optional[bool] = Field(None)

class SimpleChatRequest(BaseModel):
    message:    str           = Field(...)
    system:     Optional[str] = Field(None)
    web_search: bool          = Field(False)
    thinking:   bool          = Field(True)
    stream:     bool          = Field(False)

# ── Web UI ─────────────────────────────────────────────────────────────────────
WEB_UI = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GLM4Free</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#0f0f0f;color:#e8e8e8;height:100dvh;display:flex;flex-direction:column}
  header{padding:12px 20px;background:#1a1a1a;border-bottom:1px solid #2a2a2a;display:flex;align-items:center;gap:10px;flex-shrink:0}
  header h1{font-size:1rem;font-weight:600;color:#fff}
  #statusBadge{font-size:.72rem;color:#555;margin-left:auto}
  select{background:#222;border:1px solid #333;color:#ddd;padding:4px 8px;border-radius:6px;font-size:.8rem}
  #sysBar{padding:6px 20px;background:#141414;border-bottom:1px solid #222;display:flex;gap:8px;align-items:center;flex-shrink:0}
  #sysBar label{font-size:.72rem;color:#555;white-space:nowrap}
  #sysBar input{flex:1;background:#1a1a1a;border:1px solid #2a2a2a;color:#aaa;padding:5px 10px;border-radius:6px;font-size:.8rem;outline:none}
  #sysBar input:focus{border-color:#2563eb}
  #msgs{flex:1;overflow-y:auto;padding:16px 20px;display:flex;flex-direction:column;gap:14px}
  .msg{display:flex;gap:8px;max-width:800px;width:100%}
  .msg.user{margin-left:auto;flex-direction:row-reverse}
  .bubble{padding:9px 13px;border-radius:12px;line-height:1.55;font-size:.9rem;white-space:pre-wrap;word-break:break-word;max-width:72vw}
  .user .bubble{background:#2563eb;color:#fff;border-bottom-right-radius:3px}
  .bot  .bubble{background:#1a1a1a;border:1px solid #2a2a2a;border-bottom-left-radius:3px}
  .av{width:28px;height:28px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:700;margin-top:2px}
  .user .av{background:#2563eb;color:#fff}
  .bot  .av{background:#222;color:#888}
  .bar{padding:7px 20px;background:#141414;border-top:1px solid #222;display:flex;gap:8px;align-items:center;flex-shrink:0}
  .tog{background:#1a1a1a;border:1px solid #2a2a2a;color:#777;padding:4px 11px;border-radius:20px;font-size:.72rem;cursor:pointer;transition:all .15s}
  .tog.on{background:#1d3560;border-color:#2563eb;color:#93c5fd}
  #clr{margin-left:auto;background:#1a1a1a;border:1px solid #333;color:#666;padding:4px 11px;border-radius:20px;font-size:.72rem;cursor:pointer}
  #clr:hover{color:#f87171;border-color:#7f1d1d}
  #row{padding:10px 20px;background:#1a1a1a;border-top:1px solid #2a2a2a;display:flex;gap:8px;flex-shrink:0}
  #inp{flex:1;background:#222;border:1px solid #333;color:#e8e8e8;padding:9px 13px;border-radius:9px;font-size:.9rem;outline:none;resize:none;max-height:130px;line-height:1.4}
  #inp:focus{border-color:#2563eb}
  #snd{background:#2563eb;color:#fff;border:none;padding:9px 16px;border-radius:9px;font-size:.88rem;font-weight:600;cursor:pointer;align-self:flex-end;flex-shrink:0}
  #snd:hover{background:#1d4ed8}
  #snd:disabled{background:#1e3355;cursor:not-allowed}
  ::-webkit-scrollbar{width:3px}
  ::-webkit-scrollbar-thumb{background:#2a2a2a;border-radius:3px}
</style>
</head>
<body>
<header>
  <h1>⚡ GLM4Free</h1>
  <select id="mdl">
    <option value="glm-5">glm-5</option>
    <option value="glm-5-nothink">glm-5-nothink</option>
    <option value="glm-4.7">glm-4.7</option>
    <option value="glm-4.7-nothink">glm-4.7-nothink</option>
    <option value="glm-4.5">glm-4.5</option>
    <option value="glm-4.5-nothink">glm-4.5-nothink</option>
  </select>
  <span id="statusBadge">connecting…</span>
</header>
<div id="sysBar">
  <label>System:</label>
  <input id="sys" type="text" placeholder="Optional system prompt">
</div>
<div id="msgs"></div>
<div class="bar">
  <button class="tog"    id="tSearch" onclick="tog(this,'search')">🔍 Web Search</button>
  <button class="tog on" id="tThink"  onclick="tog(this,'think')">🧠 Thinking</button>
  <button id="clr" onclick="clrHist()">🗑 Clear</button>
</div>
<div id="row">
  <textarea id="inp" rows="1" placeholder="Message… (Enter send, Shift+Enter newline)"></textarea>
  <button id="snd" onclick="send()">Send</button>
</div>
<script>
const st={search:false,think:true};
let hist=[];
function tog(btn,k){st[k]=!st[k];btn.classList.toggle('on',st[k]);}
function clrHist(){hist=[];document.getElementById('msgs').innerHTML='';}
const inp=document.getElementById('inp');
inp.addEventListener('input',()=>{inp.style.height='auto';inp.style.height=Math.min(inp.scrollHeight,130)+'px';});
inp.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send();}});
fetch('/health').then(r=>r.json()).then(d=>{
  document.getElementById('statusBadge').textContent='● '+d.user+' · '+d.model;
}).catch(()=>{document.getElementById('statusBadge').textContent='● offline';});
function addMsg(role,text){
  const wrap=document.getElementById('msgs');
  const d=document.createElement('div');d.className='msg '+role;
  const av=document.createElement('div');av.className='av';av.textContent=role==='user'?'U':'AI';
  const b=document.createElement('div');b.className='bubble';b.textContent=text;
  d.appendChild(av);d.appendChild(b);wrap.appendChild(d);wrap.scrollTop=wrap.scrollHeight;
  return b;
}
async function send(){
  const text=inp.value.trim();if(!text)return;
  const btn=document.getElementById('snd');btn.disabled=true;
  inp.value='';inp.style.height='auto';
  addMsg('user',text);hist.push({role:'user',content:text});
  const bubble=addMsg('bot','');bubble.textContent='…';
  const model=document.getElementById('mdl').value;
  const sys=document.getElementById('sys').value.trim();
  const msgs=[];
  if(sys)msgs.push({role:'system',content:sys});
  msgs.push(...hist);
  let reply='';
  try{
    const res=await fetch('/v1/chat/completions',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({model,messages:msgs,stream:true,web_search:st.search,thinking:st.think})
    });
    bubble.textContent='';
    const reader=res.body.getReader();const dec=new TextDecoder();let buf='';
    while(true){
      const{value,done}=await reader.read();if(done)break;
      buf+=dec.decode(value,{stream:true});
      const lines=buf.split('\\n');buf=lines.pop();
      for(const line of lines){
        if(!line.startsWith('data: '))continue;
        const data=line.slice(6);if(data==='[DONE]')break;
        try{
          const c=JSON.parse(data);
          const t=c.choices?.[0]?.delta?.content||'';
          bubble.textContent+=t;reply+=t;
          document.getElementById('msgs').scrollTop=999999;
        }catch{}
      }
    }
  }catch(e){bubble.textContent='Error: '+e.message;}
  if(reply)hist.push({role:'assistant',content:reply});
  btn.disabled=false;inp.focus();
}
</script>
</body>
</html>"""

# ── Routes ─────────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
def web_ui():
    return WEB_UI

@app.get("/health")
def health():
    bot = get_bot()
    return {"status": "ok", "user": bot.user_name, "model": bot.model}

@app.get("/v1/models")
def list_models():
    return {
        "object": "list",
        "data": [{"id": m, "object": "model", "created": 1700000000, "owned_by": "z-ai"} for m in ALL_MODELS]
    }

@app.post("/chat")
def simple_chat(req: SimpleChatRequest):
    bot = get_bot()
    msgs = []
    if req.system:
        msgs.append({"role": "system", "content": req.system})
    msgs.append({"role": "user", "content": req.message})
    msgs = inject_system(msgs)
    model, _ = resolve_model("glm-5")
    gen = stream_response(bot, msgs, req.web_search, req.thinking, model)
    if req.stream:
        return StreamingResponse(gen, media_type="text/plain")
    return {"reply": "".join(gen), "model": model}

@app.post("/v1/chat/completions")
def openai_chat(req: ChatRequest):
    bot = get_bot()
    model, think = resolve_model(req.model)
    if req.thinking is not None:
        think = req.thinking
    msgs    = inject_system([{"role": m.role, "content": m.content} for m in req.messages])
    created = int(time.time())
    cid     = f"chatcmpl-{uuid.uuid4().hex[:12]}"

    if req.stream:
        def generate():
            for chunk in stream_response(bot, msgs, req.web_search, think, model):
                yield f"data: {json.dumps({'id':cid,'object':'chat.completion.chunk','created':created,'model':model,'choices':[{'index':0,'delta':{'content':chunk},'finish_reason':None}]})}\n\n"
            yield f"data: {json.dumps({'id':cid,'object':'chat.completion.chunk','created':created,'model':model,'choices':[{'index':0,'delta':{},'finish_reason':'stop'}]})}\n\ndata: [DONE]\n\n"
        return StreamingResponse(generate(), media_type="text/event-stream")

    full = "".join(stream_response(bot, msgs, req.web_search, think, model))
    return {
        "id": cid, "object": "chat.completion", "created": created, "model": model,
        "choices": [{"index": 0, "message": {"role": "assistant", "content": full}, "finish_reason": "stop"}],
        "usage": {
            "prompt_tokens": sum(len(m["content"].split()) for m in msgs),
            "completion_tokens": len(full.split()),
            "total_tokens": sum(len(m["content"].split()) for m in msgs) + len(full.split()),
        }
    }
