"""GLM4Free — unofficial free client & API for Z.AI's GLM-4 model."""
from .client import ZChat

__version__ = "1.0.0"
__all__ = ["ZChat"]
