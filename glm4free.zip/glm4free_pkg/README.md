# GLM4Free

Unofficial free client & REST API for Z.AI's GLM-4 model.

## Install

```bash
pip install .
```

That's it. Two commands are now available everywhere:

| Command | What it does |
|---------|-------------|
| `glm4free` | Interactive CLI chat |
| `glm4free-api` | Start the REST API server |

---

## API Server

```bash
glm4free-api
# or with options:
glm4free-api --host 0.0.0.0 --port 8000
```

Open **http://localhost:8000/docs** for interactive API docs.

### Endpoints

**Simple chat**
```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello!", "web_search": false, "thinking": true}'
```

**OpenAI-compatible** (works with the `openai` Python SDK)
```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "glm-4.7",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

**With the OpenAI Python SDK:**
```python
from openai import OpenAI

client = OpenAI(base_url="http://localhost:8000/v1", api_key="not-needed")
resp = client.chat.completions.create(
    model="glm-4.7",
    messages=[{"role": "user", "content": "Who are you?"}]
)
print(resp.choices[0].message.content)
```

### Extra parameters

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `web_search` | bool | `false` | Real-time web search |
| `thinking` | bool | `true` | Chain-of-thought mode |
| `stream` | bool | `false` | Stream tokens |

---

## Termux (Android)

```bash
pkg update && pkg install python
pip install .
glm4free-api
```

Find your phone IP and access from any device on the same Wi-Fi:
```bash
ip addr show wlan0   # get your phone's IP
# then on another device: http://PHONE_IP:8000
```

Run in background:
```bash
nohup glm4free-api &
```

---

## CLI Chat

```bash
glm4free
```

Commands inside the chat: `/search`, `/thinking`, `/image`, `/new`, `/history`, `/exit`

---

*Unofficial client for educational purposes. Not affiliated with Z.AI.*
