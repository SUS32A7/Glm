#!/data/data/com.termux/files/usr/bin/bash
# GLM4Free — Termux installer
# Usage: bash install.sh

set -e

echo ""
echo "╔══════════════════════════════════╗"
echo "║      GLM4Free Termux Installer   ║"
echo "╚══════════════════════════════════╝"
echo ""

# 1. Update & install Python if missing
echo "[1/3] Checking dependencies..."
if ! command -v python &>/dev/null; then
    echo "  → Installing Python..."
    pkg update -y && pkg install python -y
else
    echo "  ✓ Python $(python --version) found"
fi

# 2. Install the package
echo ""
echo "[2/3] Installing GLM4Free..."
pip install . --no-compile --no-cache-dir --quiet
echo "  ✓ Installed"

# 3. Done
echo ""
echo "[3/3] All done!"
echo ""
echo "  ┌─ Commands available ───────────────────┐"
echo "  │  glm4free        → CLI chat            │"
echo "  │  glm4free-api    → Start REST API      │"
echo "  └────────────────────────────────────────┘"
echo ""
echo "  Start the API:  glm4free-api"
echo "  Docs:           http://localhost:8000/docs"
echo ""
