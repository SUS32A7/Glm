# GLM4Free

Unofficial free client & REST API for Z.AI's GLM-4/5 models.

## Install

```bash
pip install .
```

Two commands become available:

| Command | What it does |
|---------|-------------|
| `glm4free` | Interactive CLI chat |
| `glm4free-api` | Start the REST API server |

---

## API Server

```bash
glm4free-api
# or with options:
glm4free-api --host 0.0.0.0 --port 8000
```

Open **http://localhost:8000** for the web chat UI, or **http://localhost:8000/docs** for interactive API docs.

### Endpoints

**Simple chat**
```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello!", "web_search": false, "thinking": true}'
```

**OpenAI-compatible** (works with the `openai` Python SDK)
```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "glm-4.7",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

**With the OpenAI Python SDK:**
```python
from openai import OpenAI

client = OpenAI(base_url="http://localhost:8000/v1", api_key="not-needed")
resp = client.chat.completions.create(
    model="glm-4.7",
    messages=[{"role": "user", "content": "Who are you?"}]
)
print(resp.choices[0].message.content)
```

### Available models

| Model ID | Base model | Thinking |
|---|---|---|
| `glm-5` | GLM-5 (744B MoE) | on |
| `glm-5-nothink` | GLM-5 | off |
| `glm-4.7` | GLM-4.7 | on |
| `glm-4.7-nothink` | GLM-4.7 | off |
| `glm-4.5` | GLM-4.5 (355B MoE) | on |
| `glm-4.5-nothink` | GLM-4.5 | off |

The `-nothink` suffix disables chain-of-thought reasoning. Faster responses, lower quality on complex tasks.

### Extra request fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `web_search` | bool | `false` | Real-time web search |
| `thinking` | bool | `true` | Chain-of-thought (overrides model suffix) |
| `stream` | bool | `false` | Stream tokens via SSE |

---

## SillyTavern Setup

1. Start the server: `glm4free-api`
2. In SillyTavern go to **API Connections** and select **OpenAI**
3. Set **API URL** to `http://localhost:8000/v1`
4. Set **API Key** to anything (e.g. `not-needed`)
5. Click **Connect** — the model list will populate automatically
6. Pick any model from the list (e.g. `glm-5` or `glm-5-nothink`)

System prompts, character cards, and full conversation history are all forwarded correctly.

---

## Termux (Android)

```bash
pkg update && pkg install python
pip install .
glm4free-api
```

Find your phone IP and access from any device on the same Wi-Fi:
```bash
ip addr show wlan0   # get your phone's IP
# then on another device: http://PHONE_IP:8000
```

Run in background:
```bash
nohup glm4free-api &
```

---

## CLI Chat

```bash
glm4free
```

Commands inside the chat:

| Command | Description |
|---|---|
| `/model glm-5` | Switch model (clears history) |
| `/search` | Toggle web search on/off |
| `/thinking` | Toggle chain-of-thought on/off |
| `/new` | Clear conversation history |
| `/history` | Show conversation so far |
| `/exit` | Quit |

---

*Unofficial client for educational purposes. Not affiliated with Z.AI.*
